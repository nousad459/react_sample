import React, { Fragment } from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginComponent from "../../src/Component/LoginComponent/Login";
import Registration from "../../src/Component/Registration/Registration";
import ForgotPassword from "../Component/ForgotPassword/ForgotPassword";
import HeaderComponent from "../Component/Header/Header";
import Dashboard from "../Component/Dashboard/Dashboard";
import PrivateRoute from "../Container/privateRoute";
import Sidebar from "../Component/Sidebar/Sidebar";
import FooterComponent from "../Component/Footer/Footer";
import { handleSimpleApiError, handleSimpleApiSuccess } from "../Utils/api";
import { Layout, Menu, Breadcrumb } from 'antd';
import axios from "axios";
import "antd/dist/antd.css";
import "./App.scss";
import Any from "../Component/Any/Any";
import MasterSearch from "../Component/MasterSearch/MasterSearch";

const { Header, Content, Footer, Sider } = Layout;
/***
 * This is the interceptor for handle API error and will show error notification
 * ** */
axios.interceptors.response.use(
  (res) => {
    return res;
  },
  (error) => {
    return handleSimpleApiError({
      errors: [{ response: error }],
    });
  }
);

const App = () => {
  return (
    <>
      <Router>
        <Fragment>
          <Routes>
            <Route path="*" element={() => <h1 className="page-404">404 page not found</h1>} />
            <Route exact path='/' element={<LoginComponent />} />
            {/* Private route*/}
            <Route exact element={
              <Layout style={{ minHeight: '100vh' }}>
                <Sidebar />
                <Layout className="site-layout">
                  <HeaderComponent />
                  <Content style={{ margin: '0 16px' }}>
                    <Breadcrumb style={{ margin: '16px 0' }}>
                      <Breadcrumb.Item>User</Breadcrumb.Item>
                      <Breadcrumb.Item>Bill</Breadcrumb.Item>
                    </Breadcrumb>
                    <PrivateRoute />
                  </Content>
                  <FooterComponent />
                </Layout>
              </Layout>
            }>
              {/* Private route*/}
              <Route exact path='/dashboard' element={<Dashboard />} />
              <Route exact path='/any' element={<Any />} />
              <Route exact path='/search' element={<MasterSearch />} />
              <Route path="*" element={() => <h1 >404 page not found</h1>} />
            </Route>
          </Routes>
        </Fragment>
      </Router>
    </>
  );
}

export default App;

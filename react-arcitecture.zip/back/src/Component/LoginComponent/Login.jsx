import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { Form, Input, Button, Checkbox, Row, Col, message } from "antd";
import { loginUserAction } from "../../Action/authenticationActions";
import { setCookie } from "../../Utils/cookies";
import { UserOutlined, LockOutlined } from "@ant-design/icons";
import { email, password } from "../../Utils/validation";
import PropTypes from 'prop-types';

const LoginComponent = props => {
  const [loading, setLoading] = useState(false);
  let navigate = useNavigate();
  const onFinish = async (values) => {
    console.log("Received values of form: ", values);

    setLoading(true);
    const payload = {
      "email": values.user,
      "password": values.password.trim(),
      "ipAddress": "72.229.28.185",
      "groupId": 3,
      "platForm": {
        "name": "app",
        "description": "android",
        "deviceToken": "ds_m02YqRDOBFSUBveZnaJ:APA91bFJVS2ikJdbttDDY__sJViKuFTbg0t4MPsxjKIxbjpzaui7kt1A2BA9n1sIFR28V-8OstXlr5MbPrL8N2WxyAZoJ_Z0dJvJ3zaVCZEKIlE7F4prE8EwmHxNw9xzsWq2UIIxNR2L"
      }
    };
    props.loginUserAction(payload);
  }

  useEffect(() => {
    if (
      props.login.loading === false &&
      props.login.response?.code === 200
    ) {
      message.success(props.login.response.message);
      setCookie(
        "token",
        props.login.response.result
          ? props.login.response.result.authToken
          : ""
      );
      navigate("/dashboard")
      setLoading(false);
    }
    if (
      props.login.loading === false &&
      props.login.response === undefined
    ) {
      message.success("Incorrect email or password");
      setLoading(false);
    }
  }, [props.login])
  return (
    <Row
      className="login-row"
      type="flex"
      justify="space-around"
      align="middle"
    >
      <Col span="8">
        <Form
          name="normal_login"
          className="login-form"
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
        >
          <h2 className="logo">
            <span>logo</span>
          </h2>
          <Form.Item
            name={"user"}
            rules={email}
          >
            <Input
              prefix={<UserOutlined className="site-form-item-icon" />}
              placeholder="Username"
            // maxLength={10}
            />
          </Form.Item>
          <Form.Item
            name="password"
            rules={password}
          >
            <Input.Password
              prefix={<LockOutlined className="site-form-item-icon" />}
              type="password"
              placeholder="Password"
            />
          </Form.Item>
          <Form.Item>
            <Form.Item name="remember" valuePropName="checked" noStyle>
              <Checkbox>Remember me</Checkbox>
            </Form.Item>
            {/* <a className="login-form-forgot" href=""> */}
            <Link className="login-form-forgot" to="/forgot-password">
              Forgot password
            </Link>
            {/* </a> */}
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              size="large"
              className="login-form-button"
              loading={loading}
            >
              Log in
            </Button>
          </Form.Item>
        </Form>
      </Col>
    </Row>
  );
};

LoginComponent.propTypes = {

};


const mapStateToProps = (state) => ({ login: state.auth.login });
const mapDispatchToProps = {
  loginUserAction: loginUserAction,
};
export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent);
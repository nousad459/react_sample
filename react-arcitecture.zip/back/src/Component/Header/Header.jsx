import React from 'react';
import { Layout, Menu, Breadcrumb } from 'antd';
const { Header } = Layout;

function HeaderComponent(props) {
    
    return (
        <Header className="site-layout-background" style={{ padding: 0 }} />
    );
}

export default HeaderComponent;
import React, { Component } from "react";

class Dashboard extends Component {
  
  render() {
    return (
      <div className="site-layout-background" style={{ padding: 24, minHeight: 360 }}>
        Bill is a cat.
      </div>
    );
  }
}

export default Dashboard;
